/**
 ** gles2-egl-gears
 ** Non-windowed (GF) gears that uses OpenGL ES 2.X for rendering API.
 **
 ** Features:
 **  - configurable window size through the -size=[width]x[height] option
 **  - adjustable swap interval through the -interval=[n] option;
 **    a swap interval of 0 lets the app run as fast as possible
 **    numbers of 1 or more limit the rate to the number of vsync periods
 **  - configurable layer through the -layer=[n] option
 **  - application creates itself on the default EGL display
 **  - RGBA8888 pixel format
 **  - application exits if power or mode event invalidates EGL surface
 **
 ** Copyright 2009, QNX Software Systems Ltd. All Rights Reserved
 **
 ** Permission to use, copy, modify, and distribute this software and its
 ** documentation for any purpose and without fee is hereby granted,
 ** provided that the above copyright notice appear in all copies and that
 ** both that copyright notice and this permission notice appear in
 ** supporting documentation.
 **
 ** This file is provided AS IS with no warranties of any kind.  The author
 ** shall have no liability with respect to the infringement of copyrights,
 ** trade secrets or any patents by this file or any part thereof.  In no
 ** event will the author be liable for any lost revenue or profits or
 ** other special, indirect and consequential damages.
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>

#define PLAYBOOK

EGLDisplay egl_disp;
EGLConfig egl_conf;
EGLSurface egl_surf;
EGLContext egl_ctx;
EGLint size[2];

#ifdef PLAYBOOK
#include <screen/screen.h>

screen_context_t libscr_cntx;
screen_window_t libscr_wndw;

EGLNativeWindowType getEGLNWT() {
    int rc;

    rc = screen_create_context(&libscr_cntx, SCREEN_APPLICATION_CONTEXT);
    if (rc != 0) {
        //TODO: check errno
        fprintf( stderr, "screen_create_context failed\n" );
	return (EGLNativeWindowType)0;
    }

    rc = screen_create_window(&libscr_wndw, libscr_cntx);
    if (rc != 0) {
        //TODO: check errno
        fprintf( stderr, "screen_create_window failed\n" );
        return (EGLNativeWindowType)0;
    }

    rc = screen_create_window_buffers(libscr_wndw, 2);
    if (rc != 0) {
        //TODO: check errno
        fprintf( stderr, "screen_create_window_buffers failed\n" );
        return (EGLNativeWindowType)0;
    }

    fprintf( stderr, "libscreen setup successful\n" );
    return (EGLNativeWindowType) libscr_wndw;
}

#endif

struct {
    EGLint surface_type[2];
    EGLint renderable_type[2];
    EGLint depth_size[2];
    EGLint level[2];
    EGLint transparent_type[2];
    EGLint red_size[2];
    EGLint green_size[2];
    EGLint blue_size[2];
    EGLint alpha_size[2];
    EGLint sample_buffers[2];
    EGLint samples[2];
    EGLint config_id[2];
    EGLint none;
} egl_conf_attr = {
#ifdef PLAYBOOK
	.surface_type = { EGL_SURFACE_TYPE, EGL_WINDOW_BIT },
	.renderable_type = { EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT },
	.depth_size = { EGL_DEPTH_SIZE, EGL_DONT_CARE },
	.level = { EGL_LEVEL, 0 },
	.transparent_type = { EGL_TRANSPARENT_TYPE, EGL_DONT_CARE },
	.red_size = { EGL_RED_SIZE, 8 },
	.green_size = { EGL_GREEN_SIZE, 8 },
	.blue_size = { EGL_BLUE_SIZE, 8 },
	.alpha_size = { EGL_ALPHA_SIZE, 8 },
	.sample_buffers = { EGL_SAMPLE_BUFFERS, 0 },
	.samples = { EGL_SAMPLES, 0 },
	.config_id = { EGL_CONFIG_ID, EGL_DONT_CARE },
	.none = EGL_NONE
#else
    .surface_type = { EGL_SURFACE_TYPE, EGL_WINDOW_BIT },
    .renderable_type = { EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT },
    .depth_size = { EGL_DEPTH_SIZE, 16 },
    .level = { EGL_LEVEL, 0 },
    .transparent_type = { EGL_TRANSPARENT_TYPE, EGL_DONT_CARE },
    .red_size = { EGL_RED_SIZE, EGL_DONT_CARE },
    .green_size = { EGL_GREEN_SIZE, EGL_DONT_CARE },
    .blue_size = { EGL_BLUE_SIZE, EGL_DONT_CARE },
    .alpha_size = { EGL_ALPHA_SIZE, EGL_DONT_CARE },
    .sample_buffers = { EGL_SAMPLE_BUFFERS, 0 },
    .samples = { EGL_SAMPLES, 0 },
    .config_id = { EGL_CONFIG_ID, EGL_DONT_CARE },
    .none = EGL_NONE
#endif
};

void
egl_perror(const char *msg)
{
    static const char *errmsg[] = {
        "function succeeded",
        "EGL is not initialized, or could not be initialized, for the specified display",
        "cannot access a requested resource",
        "failed to allocate resources for the requested operation",
        "an unrecognized attribute or attribute value was passed in an attribute list",
        "an EGLConfig argument does not name a valid EGLConfig",
        "an EGLContext argument does not name a valid EGLContext",
        "the current surface of the calling thread is no longer valid",
        "an EGLDisplay argument does not name a valid EGLDisplay",
        "arguments are inconsistent",
        "an EGLNativePixmapType argument does not refer to a valid native pixmap",
        "an EGLNativeWindowType argument does not refer to a valid native window",
        "one or more argument values are invalid",
        "an EGLSurface argument does not name a valid surface configured for rendering",
        "a power management event has occurred",
    };

    fprintf(stderr, "%s: %s\n", msg, errmsg[eglGetError() - EGL_SUCCESS]);
}

EGLConfig choose_config(EGLDisplay egl_disp, const char* str)
{
    EGLConfig egl_conf = (EGLConfig)0;
    EGLConfig *egl_configs;
    EGLint egl_num_configs;
    EGLint val;
    EGLBoolean rc;
    const char *tok;
    EGLint i;

    if (str != NULL) {
        tok = str;
        while (*tok == ' ' || *tok == ',') {
            tok++;
        }

        while (*tok != '\0') {
            if (strncmp(tok, "rgba8888", strlen("rgba8888")) == 0) {
                egl_conf_attr.red_size[1] = 8;
                egl_conf_attr.green_size[1] = 8;
                egl_conf_attr.blue_size[1] = 8;
                egl_conf_attr.alpha_size[1] = 8;
                tok += strlen("rgba8888");
            } else if (strncmp(tok, "rgba5551", strlen("rgba5551")) == 0) {
                egl_conf_attr.red_size[1] = 5;
                egl_conf_attr.green_size[1] = 5;
                egl_conf_attr.blue_size[1] = 5;
                egl_conf_attr.alpha_size[1] = 1;
                tok += strlen("rgba5551");
            } else if (strncmp(tok, "rgba4444", strlen("rgba4444")) == 0) {
                egl_conf_attr.red_size[1] = 4;
                egl_conf_attr.green_size[1] = 4;
                egl_conf_attr.blue_size[1] = 4;
                egl_conf_attr.alpha_size[1] = 4;
                tok += strlen("rgba4444");
            } else if (strncmp(tok, "rgb565", strlen("rgb565")) == 0) {
                egl_conf_attr.red_size[1] = 5;
                egl_conf_attr.green_size[1] = 6;
                egl_conf_attr.blue_size[1] = 5;
                egl_conf_attr.alpha_size[1] = 0;
                tok += strlen("rgb565");
            } else if (isdigit(*tok)) {
                val = atoi(tok);
                while (isdigit(*(++tok)));
                if (*tok == 'x') {
                    egl_conf_attr.sample_buffers[1] = 1;
                    egl_conf_attr.samples[1] = val;
                    tok++;
                } else {
                    egl_conf_attr.config_id[1] = val;
                }
            } else {
                fprintf(stderr, "invalid configuration specifier: ");
                while (*tok != ' ' && *tok != ',' && *tok != '\0') {
                    fputc(*tok++, stderr);
                }
                fputc('\n', stderr);
            }

            while (*tok == ' ' || *tok == ',') {
                tok++;
            }
        }
    }

    rc = eglChooseConfig(egl_disp, (EGLint*)&egl_conf_attr,
        NULL, 0, &egl_num_configs);
    if (rc != EGL_TRUE) {
        egl_perror("eglChooseConfig");
        return egl_conf;
    }
    if (egl_num_configs == 0) {
        fprintf(stderr, "eglChooseConfig: could not find a configuration\n");
        return egl_conf;
    }

    egl_configs = malloc(egl_num_configs * sizeof(*egl_configs));
    if (egl_configs == NULL) {
        fprintf(stderr, "could not allocate memory for %d EGL configs\n", egl_num_configs);
        return egl_conf;
    }

    rc = eglChooseConfig(egl_disp, (EGLint*)&egl_conf_attr,
        egl_configs, egl_num_configs, &egl_num_configs);
    if (rc != EGL_TRUE) {
        egl_perror("eglChooseConfig");
        free(egl_configs);
        return egl_conf;
    }

    for (i = 0; i < egl_num_configs; i++) {
        if (egl_conf_attr.red_size[1] != EGL_DONT_CARE) {
            eglGetConfigAttrib(egl_disp, egl_configs[i], EGL_RED_SIZE, &val);
            if (val != egl_conf_attr.red_size[1]) {
                continue;
            }
        }
        if (egl_conf_attr.green_size[1] != EGL_DONT_CARE) {
            eglGetConfigAttrib(egl_disp, egl_configs[i], EGL_GREEN_SIZE, &val);
            if (val != egl_conf_attr.green_size[1]) {
                continue;
            }
        }
        if (egl_conf_attr.blue_size[1] != EGL_DONT_CARE) {
            eglGetConfigAttrib(egl_disp, egl_configs[i], EGL_BLUE_SIZE, &val);
            if (val != egl_conf_attr.blue_size[1]) {
                continue;
            }
        }
        if (egl_conf_attr.alpha_size[1] != EGL_DONT_CARE) {
            eglGetConfigAttrib(egl_disp, egl_configs[i], EGL_ALPHA_SIZE, &val);
            if (val != egl_conf_attr.alpha_size[1]) {
                continue;
            }
        }
        egl_conf = egl_configs[i];
        break;
    }

    free(egl_configs);

    if (egl_conf == (EGLConfig)0) {
        fprintf(stderr, "eglChooseConfig: could not find a matching configuration\n");
    }
    return egl_conf;
}

int init_egl(int argc, char *argv[])
{
    struct {
        EGLint client_version[2];
        EGLint none;
    } egl_ctx_attr = {
        .client_version = { EGL_CONTEXT_CLIENT_VERSION, 2 },
        .none = EGL_NONE
    };

    struct {
        EGLint render_buffer[2];
        EGLint width[2];
        EGLint height[2];
        EGLint none;
    } egl_surf_attr = {
        .render_buffer = { EGL_RENDER_BUFFER, EGL_BACK_BUFFER },
        .width = { EGL_WIDTH, -1 },
        .height = { EGL_HEIGHT, -1 },
        .none = EGL_NONE
    };

    EGLNativeDisplayType disp_id = EGL_DEFAULT_DISPLAY;
    EGLint interval = 1;
    EGLBoolean verbose = EGL_FALSE;
    const char *conf_str = NULL;
    const char *tok;
    int rval = EXIT_FAILURE;
    int rc;
    int i;
    GLfloat r, g, b;
//    struct timespec to;
//    uint64_t t, last_t, delta;
//    int frames = 0;

    for (i = 1; i < argc; i++) {
        if (strncmp(argv[i], "-config=", strlen("-config=")) == 0) {
            conf_str = argv[i] + strlen("-config=");
        } else if (strncmp(argv[i], "-size=", strlen("-size=")) == 0) {
            tok = argv[i] + strlen("-size=");
            egl_surf_attr.width[1] = atoi(tok);
            while (*tok >= '0' && *tok <= '9') {
                tok++;
            }
            egl_surf_attr.height[1] = atoi(tok+1);
        } else if (strncmp(argv[i], "-interval=", strlen("-interval=")) == 0) {
            interval = atoi(argv[i] + strlen("-interval="));
        } else if (strncmp(argv[i], "-display=", strlen("-display=")) == 0) {
            disp_id = (EGLNativeDisplayType)atoi(argv[i] + strlen("-display="));
        } else if (strncmp(argv[i], "-layer=", strlen("-layer=")) == 0) {
            egl_conf_attr.level[1] = atoi(argv[i] + strlen("-layer="));
        } else if (strcmp(argv[i], "-single-buffer") == 0) {
            egl_surf_attr.render_buffer[1] = EGL_SINGLE_BUFFER;
        } else if (strcmp(argv[i], "-double-buffer") == 0) {
            egl_surf_attr.render_buffer[1] = EGL_BACK_BUFFER;
        } else if (strcmp(argv[i], "-verbose") == 0) {
            verbose = EGL_TRUE;
        } 
    }

    egl_disp = eglGetDisplay(disp_id);
    if (egl_disp == EGL_NO_DISPLAY) {
        egl_perror("eglGetDisplay");
        goto fail1;
    }

    rc = eglInitialize(egl_disp, NULL, NULL);
    if (rc != EGL_TRUE) {
        egl_perror("eglInitialize");
        goto fail2;
    }

    egl_conf = choose_config(egl_disp, conf_str);
    if (egl_conf == (EGLConfig)0) {
        goto fail2;
    }

    if (verbose) {
        printf("EGL_VENDOR = %s\n", eglQueryString(egl_disp, EGL_VENDOR));
        printf("EGL_VERSION = %s\n", eglQueryString(egl_disp, EGL_VERSION));
        printf("EGL_CLIENT_APIS = %s\n", eglQueryString(egl_disp, EGL_CLIENT_APIS));
        printf("EGL_EXTENSIONS = %s\n\n", eglQueryString(egl_disp, EGL_EXTENSIONS));

        i = -1;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_CONFIG_ID, &i);
        printf("EGL_CONFIG_ID = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_RED_SIZE, &i);
        printf("EGL_RED_SIZE = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_GREEN_SIZE, &i);
        printf("EGL_GREEN_SIZE = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_BLUE_SIZE, &i);
        printf("EGL_BLUE_SIZE = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_ALPHA_SIZE, &i);
        printf("EGL_ALPHA_SIZE = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_DEPTH_SIZE, &i);
        printf("EGL_DEPTH_SIZE = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_LEVEL, &i);
        printf("EGL_LEVEL = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_NATIVE_RENDERABLE, &i);
        printf("EGL_NATIVE_RENDERABLE = %s\n", i ? "EGL_TRUE" : "EGL_FALSE");

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_NATIVE_VISUAL_TYPE, &i);
        printf("EGL_NATIVE_VISUAL_TYPE = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_RENDERABLE_TYPE, &i);
        printf("EGL_RENDERABLE_TYPE = 0x%04x\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_SURFACE_TYPE, &i);
        printf("EGL_SURFACE_TYPE = 0x%04x\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_SAMPLE_BUFFERS, &i);
        printf("EGL_SAMPLE_BUFFERS = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_SAMPLES, &i);
        printf("EGL_SAMPLES = %d\n", i);

        i = 0;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_TRANSPARENT_TYPE, &i);
        if (i == EGL_TRANSPARENT_RGB) {
            printf("EGL_TRANSPARENT_TYPE = EGL_TRANSPARENT_RGB\n");

            i = 0;
            eglGetConfigAttrib(egl_disp, egl_conf, EGL_TRANSPARENT_RED_VALUE, &i);
            printf("EGL_TRANSPARENT_RED = 0x%02x\n", i);

            i = 0;
            eglGetConfigAttrib(egl_disp, egl_conf, EGL_TRANSPARENT_GREEN_VALUE, &i);
            printf("EGL_TRANSPARENT_GREEN = 0x%02x\n", i);

            i = 0;
            eglGetConfigAttrib(egl_disp, egl_conf, EGL_TRANSPARENT_BLUE_VALUE, &i);
            printf("EGL_TRANSPARENT_BLUE = 0x%02x\n\n", i);
        } else {
            printf("EGL_TRANSPARENT_TYPE = EGL_NONE\n\n");
        }
    }

#ifdef PLAYBOOK
		egl_surf_attr.width[0] = EGL_NONE;

		egl_surf = eglCreateWindowSurface(egl_disp, egl_conf,
			getEGLNWT(), (EGLint*)&egl_surf_attr);
        if (egl_surf == EGL_NO_SURFACE) {
            egl_perror("eglCreateWindowSurface");
            goto fail2;
        }
#else
    if (strncmp(eglQueryString(egl_disp, EGL_VENDOR), "QNX", strlen("QNX")) ||
        egl_surf_attr.width[1] <= 0 || egl_surf_attr.height[1] <= 0) {
        egl_surf_attr.width[0] = EGL_NONE;
    }
    egl_surf = eglCreateWindowSurface(egl_disp, egl_conf,
        (EGLNativeWindowType)egl_conf_attr.level[1], (EGLint*)&egl_surf_attr);
    if (egl_surf == EGL_NO_SURFACE) {
        egl_perror("eglCreateWindowSurface");
        goto fail2;
    }
#endif
    egl_ctx = eglCreateContext(egl_disp, egl_conf,
        EGL_NO_CONTEXT, (EGLint*)&egl_ctx_attr);
    if (egl_ctx == EGL_NO_CONTEXT) {
        egl_perror("eglCreateContext");
        goto fail3;
    }

    rc = eglMakeCurrent(egl_disp, egl_surf, egl_surf, egl_ctx);
    if (rc != EGL_TRUE) {
        egl_perror("eglMakeCurrent");
        goto fail4;
    }

    rc = eglSwapInterval(egl_disp, interval);
    if (rc != EGL_TRUE) {
        egl_perror("eglSwapInterval");
        goto fail5;
    }

    rc = eglQuerySurface(egl_disp, egl_surf, EGL_WIDTH, &size[0]);
    if (rc != EGL_TRUE) {
        egl_perror("eglQuerySurface");
        goto fail5;
    }

    rc = eglQuerySurface(egl_disp, egl_surf, EGL_HEIGHT, &size[1]);
    if (rc != EGL_TRUE) {
        egl_perror("eglQuerySurface");
        goto fail5;
    }

    eglGetConfigAttrib(egl_disp, egl_conf, EGL_TRANSPARENT_TYPE, &i);

    if (i == EGL_TRANSPARENT_RGB) {
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_TRANSPARENT_RED_VALUE, &i);
        r = (float)i / 255;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_TRANSPARENT_GREEN_VALUE, &i);
        g = (float)i / 255;
        eglGetConfigAttrib(egl_disp, egl_conf, EGL_TRANSPARENT_BLUE_VALUE, &i);
        b = (float)i / 255;
    } else {
        r = 0.0f;
        g = 0.0f;
        b = 1.0f;
    }

    if (verbose) {
        printf("GL_VENDOR = %s\n", (char *)glGetString(GL_VENDOR));
        printf("GL_RENDERER = %s\n", (char *)glGetString(GL_RENDERER));
        printf("GL_VERSION = %s\n", (char *)glGetString(GL_VERSION));
        printf("GL_EXTENSIONS = %s\n", (char *)glGetString(GL_EXTENSIONS));
    }

#if 0
    glClearColor(r, g, b, 0.0f);

    clock_gettime(CLOCK_REALTIME, &to);
    last_t = timespec2nsec(&to);

    while (1) {
        draw(egl_disp, egl_surf);

        rc = eglSwapBuffers(egl_disp, egl_surf);
        if (rc != EGL_TRUE) {
            egl_perror("eglSwapBuffers");
            break;
        }

        frames++;

        clock_gettime(CLOCK_REALTIME, &to);
        t = timespec2nsec(&to);
        delta = t - last_t;
        if (delta >= 5000000000LL) {
            printf("%d frames in %6.3f seconds = %6.3f FPS\n",
                frames, 0.000000001f * delta, 1000000000.0f * frames / delta);
            last_t = t;
            frames = 0;
        }
    }
#endif

    rval = EXIT_SUCCESS;
    return rval;

fail5:
    eglMakeCurrent(egl_disp, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
fail4:
    eglDestroyContext(egl_disp, egl_ctx);
fail3:
    eglDestroySurface(egl_disp, egl_surf);
fail2:
    eglTerminate(egl_disp);
fail1:
    eglReleaseThread();
    return rval;
}

__SRCVERSION( "$URL: http://svn.ott.qnx.com/product/trunk/apps/egl/demos/gles1-egl-gears/gles1-egl-gears.c $ $Rev: 219465 $" );
