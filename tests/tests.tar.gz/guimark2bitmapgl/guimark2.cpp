#include <stdlib.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <SkBitmap.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <string>
#include <signal.h>

#include "SkGpuDevice.h"
#include "SkGpuDeviceFactory.h"
#include "SkCanvas.h"
#include "SkGraphics.h"
#include "SkPicture.h"
#include "SkStream.h"
#include "SkString.h"
#include "SkTemplates.h"
#include "SkGpuCanvas.h"
#include "SkShader.h"
#include "SkGrTexturePixelRef.h"
#include "GrContext.h"
#include "SkGpuDevice.h"
#include "SkImageDecoder.h"
#include "SkImageRef.h"
#include "SkRandom.h"

#ifndef PLAYER_NO_EGL
#include <EGL/egl.h>
#include <GLES2/gl2.h>

extern EGLDisplay egl_disp;
extern EGLConfig  egl_conf;
extern EGLSurface egl_surf;
extern EGLContext egl_ctx;
extern EGLint     size[2];

#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 600
#define PI 3.14159265
#define NMONSTERS 100
#define NEXPLOSIONS 8
typedef unsigned char byte;

extern "C" int init_egl(int argc, char* argv[]);
#endif

static const char* south[] = {
    "s1.png", "s2.png", "s3.png"
};
static const char* east[] = {
    "e1.png", "e2.png", "e3.png"
};
static const char* west[] = {
    "w1.png", "w2.png", "w3.png"
};
static const char* north[] = {
    "n1.png", "n2.png", "n3.png"
};
static const char* bomb[] = {
    "e_f01.png", "e_f02.png", "e_f03.png",
    "e_f04.png", "e_f05.png", "e_f06.png",
    "e_f07.png", "e_f08.png"
};
static const char* back[] = {
    "lighthouse.png", "lighthousetop.png"
};
static const char* tile[] = {
    "groundtile.png"
};
struct Bitmap {
    GLuint texID;
    int width;
    int height;
};

class FramedBitmap {
public:
int frame;
GLfloat x,y,xMove,yMove,scale;

Bitmap* bitmaps;
int length;

FramedBitmap(){};

void increment(){
	if(++frame >= length){
		frame = 0;
	}
}
void randomize(){
	frame = floor((float)rand()/RAND_MAX*length);
}
void setBitmap(Bitmap* sourceArray, int N){
	bitmaps = &sourceArray[0];
	length = N;
}

Bitmap* getBitmap(){
	return &bitmaps[frame];
}
Bitmap* getNextBitmap(){
	increment();
	return getBitmap();
}

};

Bitmap* ReadBitmap(const char* names[], int N){
    Bitmap* bitmaps = new Bitmap[N];

    for (int i = 0; i < N; i++) {
        SkBitmap bitmap;
        std::string str("assets/");
        str.append(names[i]);

    	if(!SkImageDecoder::DecodeFile(str.c_str(), &bitmap,
    	        SkBitmap::kARGB_8888_Config, SkImageDecoder::kDecodePixels_Mode))
    		return NULL;

    	bitmaps[i].width = bitmap.width();
    	bitmaps[i].height = bitmap.height();

        printf("Reading %s w:%d h:%d\n",str.c_str(), bitmap.width(), bitmap.height());

        glGenTextures(1,&bitmaps[i].texID);
        glBindTexture(GL_TEXTURE_2D, bitmaps[i].texID);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, bitmaps[i].width, bitmaps[i].height, 0, GL_RGBA, GL_UNSIGNED_BYTE, bitmap.getPixels());
    }
    return bitmaps;
}
Bitmap* ReadBitmapTiled(const char* names[], int N){
    Bitmap* bitmaps = new Bitmap[N];

    for (int i = 0; i < N; i++) {
        SkBitmap bitmap;
        std::string str("assets/");
        str.append(names[i]);

        if(!SkImageDecoder::DecodeFile(str.c_str(), &bitmap,
                SkBitmap::kARGB_8888_Config, SkImageDecoder::kDecodePixels_Mode))
            return NULL;

        bitmaps[i].width = bitmap.width();
        bitmaps[i].height = bitmap.height();

        printf("Reading %s w:%d h:%d\n",str.c_str(), bitmap.width(), bitmap.height());

        glGenTextures(1,&bitmaps[i].texID);
        glBindTexture(GL_TEXTURE_2D, bitmaps[i].texID);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, bitmaps[i].width, bitmaps[i].height, 0, GL_RGBA, GL_UNSIGNED_BYTE, bitmap.getPixels());
    }
    return bitmaps;
}
FramedBitmap monsters[600];
FramedBitmap explosions[8];
Bitmap* background;
Bitmap* tower;

int programs[2];
void drawBitmap(Bitmap* bitmap,float left, float top, float scale){

    glBindTexture(GL_TEXTURE_2D, bitmap->texID);

    GLfloat mvp[] = {2.0/SCREEN_WIDTH*bitmap->width/scale,0,0,
                    0,-2.0/SCREEN_HEIGHT*bitmap->height/scale,0,
                    -1+2*left/SCREEN_WIDTH,1-2*top/SCREEN_HEIGHT,1.0};

    GLuint mvp_matrix = glGetUniformLocation( programs[0], "uViewM" );
    glUniformMatrix3fv(mvp_matrix, 1,GL_FALSE,mvp);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
}

void processFrame(){
    glClearColor(0.5,0.5,0.5,1);
    glClear(GL_COLOR_BUFFER_BIT);

    glUseProgram(programs[0]);
	//position monsters
	for(int i=0; i<NMONSTERS; i++){
		FramedBitmap* fb = &monsters[i];
		fb->x += fb->xMove;
		fb->y += fb->yMove;
		if(fb->x < -40){
			fb->x += 1240;
		}else if(fb->x > 1200){
			fb->x -= 1240;
		}
		if(fb->y < -40){
			fb->y += 640;
		}else if(fb->y > 600){
			fb->y -= 640;
		}
		drawBitmap(fb->getNextBitmap(), fb->x/fb->scale, fb->y/fb->scale,fb->scale/5);
	}
}

void create_programs(int programs[2]) {
    const char* vShader =
            "uniform mat4 mvp_matrix;\n"
            "attribute vec2 position;\n"
            "void main() {\n"
            "   gl_Position = mvp_matrix*vec4(position, 0, 1);\n"
            "}\n";

    const char* fShader =
            "precision mediump float;\n"
            "void main() {\n"
            "   gl_FragColor = vec4(1,0,0,1);\n"
            "}\n";

    const char* vss =
            "uniform mat3 uViewM;\n"
            "attribute vec2 aPosition;\n"
            "varying vec2 vStage0;\n"
            "void main() {\n"
            "   vec3 pos3 = uViewM * vec3(aPosition, 1);\n"
            "   gl_Position = vec4(pos3.xy, 0, pos3.z);\n"
            "   vStage0 = aPosition;\n"
            "}\n";

    const char* fss =
            "precision mediump float;\n"
            "uniform sampler2D uSampler0;\n"
            "varying vec2 vStage0;\n"
            "void main() {\n"
            "    vec4 color0;\n"
            "    color0 = texture2D(uSampler0, vec2(vStage0.x, vStage0.y));"
            "    gl_FragColor = vec4(color0);"
            "}";


    GLuint program = glCreateProgram();

    GLuint vs = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vs, 1, &vss, NULL);
    glCompileShader(vs);
    glAttachShader(program, vs);

    GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fs, 1, &fss, NULL);
    glCompileShader(fs);
    glAttachShader(program, fs);

    glLinkProgram(program);

    char buffer[1024];
    glGetProgramInfoLog(program, 1024, NULL, buffer);
    printf("INFO %s\n", buffer);
    glGetShaderInfoLog(fs, 1024, NULL, buffer);
    printf("FRAGMENT %s\n", buffer);
    programs[0] = program;

    program = glCreateProgram();
    vs = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vs, 1, &vShader, NULL);
    glCompileShader(vs);
    glAttachShader(program, vs);

    fs = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fs, 1, &fShader, NULL);
    glCompileShader(fs);
    glAttachShader(program, fs);

    glLinkProgram(program);

    glGetProgramInfoLog(program, 1024, NULL, buffer);
    printf("INFO %s\n", buffer);
    glGetShaderInfoLog(fs, 1024, NULL, buffer);
    printf("FRAGMENT %s\n", buffer);
    programs[1] = program;
}

int main (int argc, char* argv[]) {
	printf("%d: Init EGL\n", __LINE__);
    if (init_egl(argc, argv) != EXIT_SUCCESS) {
    	printf("%d, Failed To Init EGL\n", __LINE__);
    }
    create_programs(programs);

    //Read bitmaps
	Bitmap* southWalk = ReadBitmap(south,3);
	Bitmap* eastWalk = ReadBitmap(east,3);
	Bitmap* westWalk = ReadBitmap(west,3);
	Bitmap* northWalk = ReadBitmap(north,3);
    background = ReadBitmapTiled(tile,1);
	tower = ReadBitmap(back,3);
    Bitmap* explosion = ReadBitmap(bomb,8);

	GLfloat R = PI/180;
	//create monsters
	for(int i=0; i<NMONSTERS; i++){
		GLfloat speed = 3+((float)rand()/RAND_MAX*2);
		GLfloat angle = (float)rand()/RAND_MAX*360;

		FramedBitmap *fb = &monsters[i];
		if(angle >= 45 && angle < 135){
			fb->setBitmap(southWalk,3);
		}else if(angle >= 135 && angle < 225){
			fb->setBitmap(westWalk,3);
		}else if(angle >= 225 && angle < 315){
			fb->setBitmap(northWalk,3);
		}else{
			fb->setBitmap(eastWalk,3);
		}
		fb->x = (float)rand()/RAND_MAX*SCREEN_WIDTH;
		fb->y = (float)rand()/RAND_MAX*SCREEN_HEIGHT;
		fb->xMove = cos(angle*R)*speed;
		fb->yMove = sin(angle*R)*speed;
		fb->scale = 0.5+((float)rand()/RAND_MAX*0.7);
		fb->randomize();
	}

	//create explosions
	for(int i=0; i<8; i++){
		FramedBitmap* fb = &explosions[i];
		fb->setBitmap(explosion,8);
		fb->frame = i;
		fb->x = -200;
		fb->y = -200;
	}

	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	SkDebugf("%d: Bind Default FrameBuffer - GLError: %x\n", __LINE__, glGetError());

	glViewport(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
	SkDebugf("%d: glViewport - GLError: %x\n", __LINE__, glGetError());

    //Bitmap Shader
    glUseProgram(programs[0]);

    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    GLuint textureLocation = glGetUniformLocation( programs[0], "uSampler0" );
    GLuint attr_texcoordLoc = glGetAttribLocation( programs[0], "aPosition" );

    float texcoords[] = { 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f };
    glUniform1i(textureLocation, 0);

    glEnableVertexAttribArray( attr_texcoordLoc );
    glVertexAttribPointer( attr_texcoordLoc, 2, GL_FLOAT, GL_FALSE, 0, texcoords );
    glEnable(GL_BLEND);
    glActiveTexture(GL_TEXTURE0);

    struct timespec to;
	uint64_t t, last_t, delta;
	int frames = 0;

	while(1){
		processFrame();

	    glFlush();
		eglSwapBuffers(egl_disp, egl_surf);
        frames++;

        clock_gettime(CLOCK_REALTIME, &to);
        t = timespec2nsec(&to);
        delta = t - last_t;
        if (delta >= 5000000000LL) {
            printf("%d frames in %6.3f seconds = %6.3f FPS\n",
                frames, 0.000000001f * delta, 1000000000.0f * frames / delta);
            last_t = t;
            frames = 0;
        }
	}
    return 0;
}


