#include <stdlib.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <SkBitmap.h>
#include <string>
#include <signal.h>

#include "SkGpuDevice.h"
#include "SkGpuDeviceFactory.h"
#include "SkCanvas.h"
#include "SkGraphics.h"
#include "SkPicture.h"
#include "SkStream.h"
#include "SkString.h"
#include "SkTemplates.h"
#include "SkGpuCanvas.h"
#include "SkShader.h"
#include "SkGrTexturePixelRef.h"
#include "GrContext.h"
#include "SkGpuDevice.h"
#include "SkImageDecoder.h"
#include "SkImageRef.h"
#include "SkRandom.h"

#ifndef PLAYER_NO_EGL
#include <EGL/egl.h>
#include <GLES2/gl2.h>

extern EGLDisplay egl_disp;
extern EGLConfig  egl_conf;
extern EGLSurface egl_surf;
extern EGLContext egl_ctx;
extern EGLint     size[2];

#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 600
#define PI 3.14159265
#define NMONSTERS 600
#define NEXPLOSIONS 8
typedef unsigned char byte;

extern "C" int init_egl(int argc, char* argv[]);
#endif

static const char* south[] = {
    "s1.png", "s2.png", "s3.png"
};
static const char* east[] = {
    "e1.png", "e2.png", "e3.png"
};
static const char* west[] = {
    "w1.png", "w2.png", "w3.png"
};
static const char* north[] = {
    "n1.png", "n2.png", "n3.png"
};
static const char* bomb[] = {
    "e_f01.png", "e_f02.png", "e_f03.png",
    "e_f04.png", "e_f05.png", "e_f06.png",
    "e_f07.png", "e_f08.png"
};

class FramedBitmap {
public:
int frame;
GLfloat x,y,xMove,yMove,scale;

SkBitmap* bitmaps;
int length;

FramedBitmap(){};

void increment(){
	if(++frame >= length){
		frame = 0;
	}
}
void randomize(){
	frame = floor((float)rand()/RAND_MAX*length);
}
void setBitmap(SkBitmap* sourceArray, int N){
	bitmaps = &sourceArray[0];
	length = N;
}

SkBitmap * getBitmap(){
	return &bitmaps[frame];
}
SkBitmap * getNextBitmap(){
	increment();
	return getBitmap();
}

};

SkBitmap* ReadBitmap(const char* names[], int N){
    SkBitmap* fBitmaps = new SkBitmap[N];
    for (int i = 0; i < N; i++) {
        std::string str("assets/");
        str.append(names[i]);
    	if(!SkImageDecoder::DecodeFile(str.c_str(),&fBitmaps[i]))
    		return NULL;
        fBitmaps[i].buildMipMap();
    }
    return fBitmaps;
}

FramedBitmap monsters[NMONSTERS];
FramedBitmap explosions[NEXPLOSIONS];
SkBitmap background[3];
SkShader* tileShader;
static GrContext* g_context;

void processFrame(SkCanvas& canvas){
	canvas.drawColor( SkColorSetARGB(255, 255, 255, 255) );
	//draw ground
	SkPaint paint;
	paint.setShader(tileShader);

	SkRect rect = SkRect::MakeWH(SkIntToScalar(SCREEN_WIDTH),SkIntToScalar(SCREEN_HEIGHT));
	canvas.drawRect(rect,paint);

	//position monsters
	for(int i=0; i<NMONSTERS; i++){
		FramedBitmap* fb = &monsters[i];
		fb->x += fb->xMove;
		fb->y += fb->yMove;
		if(fb->x < -40){
			fb->x += 1240;
		}else if(fb->x > 1200){
			fb->x -= 1240;
		}
		if(fb->y < -40){
			fb->y += 640;
		}else if(fb->y > 600){
			fb->y -= 640;
		}

		if(fb->y <= 330){
			canvas.save();
			canvas.scale(fb->scale, fb->scale);
			canvas.drawBitmap(*fb->getNextBitmap(), fb->x/fb->scale, fb->y/fb->scale);
			canvas.restore();
		}
	}

	//draw tower
	canvas.drawBitmap(background[1], 550, 100);

	//draw monsters above tower
	for(int i=0; i<NMONSTERS; i++){
		FramedBitmap* fb = &monsters[i];
		if(fb->y > 330){
			canvas.save();
			canvas.scale(fb->scale, fb->scale);
			canvas.drawBitmap(*fb->getNextBitmap(), fb->x/fb->scale, fb->y/fb->scale);
			canvas.restore();
		}
	}
	//draw laser and explosions
	for(int i=0; i<NEXPLOSIONS; i++){
		FramedBitmap *fb = &explosions[i];
		if(fb->frame == 0){
			GLfloat dist = 200;
			GLfloat angle = (float)rand()/RAND_MAX*360*PI/(GLfloat)180;
			fb->x = 520+(cos(angle)*dist);
			fb->y = 270+(sin(angle)*dist);

			SkPath path;
			path.moveTo(SkIntToScalar(612),SkIntToScalar(180));
			path.lineTo(SkFloatToScalar(fb->x + 83),SkFloatToScalar(fb->y + 70));
			path.close();

			SkPaint paint;
			paint.setStyle(SkPaint::kStroke_Style);
			paint.setStrokeWidth(SkIntToScalar(3));
			paint.setColor(SkColorSetARGB(0xff,0xff, 0x00, 0x00));

			canvas.drawPath(path,paint);
		}
		canvas.drawBitmap(*fb->getNextBitmap(), SkFloatToScalar(fb->x), SkFloatToScalar(fb->y));
	}

	//draw tower top
	canvas.drawBitmap(background[2], 570, 124);
}

int main (int argc, char* argv[]) {
	SkDebugf("%d: Init EGL\n", __LINE__);
    if (init_egl(argc, argv) != EXIT_SUCCESS) {
    	SkDebugf("%d, Failed To Init EGL\n", __LINE__);
    }

	SkBitmap bitmap;
	bitmap.setConfig( SkBitmap::kARGB_8888_Config, SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_WIDTH*4 );
	bitmap.allocPixels();

	SkDebugf("%d: Create GrContext - GLError: %x\n", __LINE__, glGetError());
	g_context = GrContext::Create(kOpenGL_Shaders_GrEngine, 0);
	SkDebugf("%d: Create SkGpuCanvas - GLError: %x\n", __LINE__, glGetError());

	SkGpuCanvas canvas( g_context , SkGpuDevice::Current3DApiRenderTarget());
	SkDeviceFactory* f = new SkGpuDeviceFactory(g_context , SkGpuDevice::Current3DApiRenderTarget());
	SkDevice* device  = f->newDevice(&canvas,bitmap.getConfig(), SCREEN_WIDTH, SCREEN_HEIGHT, true, false );

	canvas.setDevice( device );

	SkBitmap* southWalk = ReadBitmap(south,3);
	SkBitmap* eastWalk = ReadBitmap(east,3);
	SkBitmap* westWalk = ReadBitmap(west,3);
	SkBitmap* northWalk = ReadBitmap(north,3);

	GLfloat R = PI/180;
	SkRandom rand;
	//create monsters
	for(int i=0; i<NMONSTERS; i++){
		GLfloat speed = 3+(rand.nextUScalar1()*2);
		GLfloat angle = rand.nextUScalar1()*360;

		FramedBitmap *fb = &monsters[i];
		if(angle >= 45 && angle < 135){
			fb->setBitmap(southWalk,3);
		}else if(angle >= 135 && angle < 225){
			fb->setBitmap(westWalk,3);
		}else if(angle >= 225 && angle < 315){
			fb->setBitmap(northWalk,3);
		}else{
			fb->setBitmap(eastWalk,3);
		}
		fb->x = rand.nextUScalar1()*1200;
		fb->y = rand.nextUScalar1()*600;
		fb->xMove = cos(angle*R)*speed;
		fb->yMove = sin(angle*R)*speed;
		fb->scale = 0.5+(rand.nextUScalar1()*0.7);
		fb->randomize();
	}

	//create explosions
	SkBitmap* explosion = ReadBitmap(bomb,8);
	for(int i=0; i<8; i++){
		FramedBitmap* fb = &explosions[i];
		fb->setBitmap(explosion,8);
		fb->frame = i;
		fb->x = -200;
		fb->y = -200;
	}

	//create background

	//ground
	if(!SkImageDecoder::DecodeFile("assets/groundtile.png",&background[0]))
		return -1;
	tileShader = SkShader::CreateBitmapShader(background[0], SkShader::kRepeat_TileMode, SkShader::kRepeat_TileMode);

	//tower base
	if(!SkImageDecoder::DecodeFile("assets/lighthouse.png",&background[1]))
		return -1;
	background[1].buildMipMap();

	//tower top
	if(!SkImageDecoder::DecodeFile("assets/lighthousetop.png",&background[2]))
		return -1;
	background[2].buildMipMap();

	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	SkDebugf("%d: Bind Default FrameBuffer - GLError: %x\n", __LINE__, glGetError());

	glViewport(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
	SkDebugf("%d: glViewport - GLError: %x\n", __LINE__, glGetError());

	struct timespec to;
	uint64_t t, last_t, delta;
	int frames = 0;
	while(1){
		processFrame(canvas);
		device->flush();
		//g_context->printStats();
		eglSwapBuffers(egl_disp, egl_surf);
        frames++;

        clock_gettime(CLOCK_REALTIME, &to);
        t = timespec2nsec(&to);
        delta = t - last_t;
        if (delta >= 5000000000LL) {
            printf("%d frames in %6.3f seconds = %6.3f FPS\n",
                frames, 0.000000001f * delta, 1000000000.0f * frames / delta);
            last_t = t;
            frames = 0;
        }
	}
    return 0;
}


