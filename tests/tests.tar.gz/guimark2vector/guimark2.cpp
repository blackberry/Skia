#include <stdlib.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <SkBitmap.h>
#include <string>
#include <signal.h>
#include <deque>
#include "SkGpuDevice.h"
#include "SkGpuDeviceFactory.h"
#include "SkCanvas.h"
#include "SkGraphics.h"
#include "SkPicture.h"
#include "SkStream.h"
#include "SkString.h"
#include "SkTemplates.h"
#include "SkGpuCanvas.h"
#include "SkShader.h"
#include "SkGrTexturePixelRef.h"
#include "GrContext.h"
#include "SkGpuDevice.h"
#include "SkImageDecoder.h"
#include "SkImageRef.h"
#include "SkRandom.h"

#include <EGL/egl.h>
#include <GLES2/gl2.h>

extern EGLDisplay egl_disp;
extern EGLConfig  egl_conf;
extern EGLSurface egl_surf;
extern EGLContext egl_ctx;
extern EGLint     size[2];

typedef unsigned char byte;

extern "C" int init_egl(int argc, char* argv[]);

struct StockVO{
    int minute;
    float value;
    StockVO(){};
    StockVO(int minute, float value){
        this->minute = minute;
        this->value = value;
    }
};
using namespace std;
int chartWidth = 1200;
int chartHeight = 600;
int highestStock = 200;
int totalMinutes = 480;
float chartXSpread;
float chartYSpread;

deque<StockVO> a;
deque<StockVO> b;
deque<StockVO> c;
deque<StockVO> d;
deque<StockVO> e;

void fillStockData(deque<StockVO> &data, float region){
    int diff = 15;
    int low = region-(diff/2);
    int i = 0;

    if(data.size() == 0){
        while(i <= totalMinutes){
            StockVO stock(i, (float)rand()/RAND_MAX*diff+low);
            data.push_back(stock);
            i++;
        }
    }else{
        while(i <= totalMinutes){
            data[i].minute--;
            i++;
        }
        StockVO stock = data.front();
        stock.minute = totalMinutes;
        stock.value = (float)rand()/RAND_MAX*diff+low;
        data.pop_front();
        data.push_back(stock);
    }
}

void graphStockData(SkCanvas &canvas, deque<StockVO> &topData, deque<StockVO> &bottomData, SkColor line, SkColor fill){
    StockVO stock;
    float xCoord;
    float yCoord;
    int i = 0;

    SkPath path;

    SkPaint sPaint;
    sPaint.setStyle(SkPaint::kStroke_Style);
    sPaint.setStrokeWidth(SkIntToScalar(2));
    sPaint.setColor(line);
    sPaint.setStrokeCap(SkPaint::kRound_Cap);
    sPaint.setStrokeJoin(SkPaint::kRound_Join);

    SkPaint fPaint;
    fPaint.setStyle(SkPaint::kFill_Style);
    fPaint.setColor(fill);

    stock = topData[i];
    xCoord = stock.minute*chartXSpread;
    yCoord = chartHeight-stock.value*chartYSpread;
    path.moveTo(xCoord, yCoord);

    while(++i < topData.size()){
        stock = topData[i];
        xCoord = stock.minute*chartXSpread;
        yCoord = chartHeight-stock.value*chartYSpread;
        path.lineTo(xCoord, yCoord);
    }
    canvas.drawPath(path,sPaint);

    if(bottomData.size() > 0){
        i = bottomData.size();
        while(--i > -1){
            stock = bottomData[i];
            xCoord = stock.minute*chartXSpread;
            yCoord = chartHeight-stock.value*chartYSpread;
            path.lineTo(xCoord, yCoord);
        }
    }else{
        path.lineTo(chartWidth, chartHeight);
        path.lineTo(0, chartHeight);
    }
    path.close();
    canvas.drawPath(path,fPaint);
}

void processFrame(SkCanvas &canvas){
	canvas.clear( SkColorSetARGB(255, 255, 255, 255) );

	SkPath path;

    SkPaint paint;
    paint.setStyle(SkPaint::kStroke_Style);
    paint.setStrokeWidth(SkIntToScalar(1));
    paint.setColor(SkColorSetARGB(0x66,0x66, 0x66, 0x66));

    float xCoord;
    float yCoord;
    for(int x=0; x<=totalMinutes; x+=40){
        xCoord = x*chartXSpread+0.5;
        path.moveTo(xCoord, 0);
        path.lineTo(xCoord, chartHeight);
    }
    for(int y=0; y<=highestStock; y+=20){
        yCoord = y*chartYSpread+0.5;
        path.moveTo(0, yCoord);
        path.lineTo(chartWidth, yCoord);
    }
    path.close();
    canvas.drawPath(path,paint);

    fillStockData(a, 180);
    fillStockData(b, 140);
    fillStockData(c, 100);
    fillStockData(d, 60);
    fillStockData(e, 20);

    deque<StockVO> null;
    graphStockData(canvas, a, b, SkColorSetRGB(0xFF,0x00,0xFF), SkColorSetARGB(153, 255, 176, 255));
    graphStockData(canvas, b, c, SkColorSetRGB(0xFF,0x00,0x00), SkColorSetARGB(153, 255, 176, 176));
    graphStockData(canvas, c, d, SkColorSetRGB(0xFF,0x66,0x00),SkColorSetARGB(153, 255, 216, 176));
    graphStockData(canvas, d, e, SkColorSetRGB(0x00,0x00,0xff), SkColorSetARGB(153, 176, 176, 255));
    graphStockData(canvas, e, null, SkColorSetRGB(0x00,0xFF,0x00), SkColorSetARGB(153, 176, 255, 176));

}

int main (int argc, char* argv[]) {
	SkDebugf("%d: Init EGL\n", __LINE__);
    if (init_egl(argc, argv) != EXIT_SUCCESS) {
    	SkDebugf("%d, Failed To Init EGL\n", __LINE__);
    }

	SkDebugf("%d: Create GrContext - GLError: %x\n", __LINE__, glGetError());
	GrContext* g_context = GrContext::CreateGLShaderContext();

	SkDebugf("%d: Create SkGpuCanvas - GLError: %x\n", __LINE__, glGetError());
	SkGpuCanvas canvas(g_context, SkGpuDevice::Current3DApiRenderTarget());
	SkGpuDevice device(g_context, SkBitmap::kARGB_8888_Config, chartWidth, chartHeight);
	canvas.setDevice( &device );

	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	SkDebugf("%d: Bind Default FrameBuffer - GLError: %x\n", __LINE__, glGetError());

	glViewport(0, 0, chartWidth, chartHeight);
	SkDebugf("%d: glViewport - GLError: %x\n", __LINE__, glGetError());

    chartXSpread = (float)chartWidth/totalMinutes;
    chartYSpread = (float)chartHeight/highestStock;

	struct timespec to;
	uint64_t t, last_t, delta;
	int frames = 0;

	while(1){

		processFrame(canvas);
		device.flush();

		eglSwapBuffers(egl_disp, egl_surf);
        frames++;
        clock_gettime(CLOCK_REALTIME, &to);
        t = timespec2nsec(&to);
        delta = t - last_t;
        if (delta >= 5000000000LL) {
            printf("%d frames in %6.3f seconds = %6.3f FPS\n",
                frames, 0.000000001f * delta, 1000000000.0f * frames / delta);
            last_t = t;
            frames = 0;
        }
	}
    return 0;
}


